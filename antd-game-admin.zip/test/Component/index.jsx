import React from 'react';
import { expect } from 'chai';


describe('Shallow Rendering', () => {
  it('App\'s tag should be h1', () => {

  });
});

import React, { Component } from 'react';

class NotFoundPage extends Component {
  render() {
    return (
      <div className="App">
        404 页面
      </div>
    );
  }
}

export default NotFoundPage;
